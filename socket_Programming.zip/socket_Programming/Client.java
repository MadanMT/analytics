package com.avanseus;

import java.io.*;
import java.net.Socket;

/**
 * Created by madan on 18/4/17.
 */
public class Client {

    public void sendDataToServer(String ipAddress, int port,String message){
        try {
            Socket socket = new Socket(ipAddress,port);
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
            System.out.println(" inter net address : "+socket.getInetAddress()+" , Local ip address : "+socket.getLocalAddress()+" , socket address : "+socket.getLocalSocketAddress()+" , port number  : "+socket.getPort());
            dataOutputStream.writeUTF(message);
            DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
            String serverResponse = dataInputStream.readUTF();
            System.out.println("server says : "+serverResponse);
            dataOutputStream.flush();
            dataOutputStream.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendAndReceiveData(String ipAddress, int port, String message){
        try {
            Socket s=new Socket(ipAddress,port);
            DataInputStream din=new DataInputStream(s.getInputStream());
            DataOutputStream dout=new DataOutputStream(s.getOutputStream());
//            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

            String str="",str2="";
            while(!str.equals("stop")){
                str=message;
                dout.writeUTF(str);
                dout.flush();
                str2=din.readUTF();
                System.out.println("Server says: "+str2);
            }

            dout.close();
            s.close();
        }catch (IOException e){
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        Client client = new Client();
//        client.sendDataToServer("localhost",8081);
        client.sendAndReceiveData("localhost",6666,"test");
    }
}
