package com.avanseus;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Created by madan on 18/4/17.
 */
public class Server {
    public static  Server server = null;


    public Server() {
        receiveDataFromClient();
    }

    public static synchronized Server getInstance(){
        if (server == null){
            server = new Server();
        }
        return server;
    }

    public void receiveDataFromClient(){
        try {
            ServerSocket serverSocket = new ServerSocket(6666);
            Socket socket = serverSocket.accept();
            DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
            String message = dataInputStream.readUTF();
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
            dataOutputStream.writeUTF(message+" successfully received..." );
            dataOutputStream.flush();
            dataOutputStream.close();
            System.out.println("client says  : "+message);
            socket.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void receiveAndResponse(int port, String message){
        try {
            ServerSocket ss=new ServerSocket(port);
            Socket s=ss.accept();
            DataInputStream din=new DataInputStream(s.getInputStream());
            DataOutputStream dout=new DataOutputStream(s.getOutputStream());
//            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

            String str="",str2="";
            while(!str.equals("stop")){
                str=din.readUTF();
                System.out.println("client says: "+str);
                str2=/*br.readLine()*/message;
                dout.writeUTF(str2);
                dout.flush();
            }
            din.close();
            s.close();
            ss.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Server server = new Server();
//        server.receiveDataFromClient(8081);
        server.receiveAndResponse(6666,"server");
    }
}
